import { Component, OnInit } from '@angular/core';
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';

@Component({
  selector: 'app-imagegallery',
  templateUrl: './image-gallery.component.html',
  styleUrls: ['./image-gallery.component.css']
})
export class ImageGalleryComponent implements OnInit {

  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[];
  constructor() {
  }
  ngOnInit() {
      this.galleryOptions = [
          {
              width: '600px',
              height: '400px',
              thumbnailsColumns: 4,
              imageAnimation: NgxGalleryAnimation.Fade,
          },
      ];
      this.galleryImages = [
          {
              small: 'http://localhost/images/1.jpeg',
              medium: 'http://localhost/images/1.jpeg',
              big: 'http://localhost/images/1.jpeg'
          },
          {
              small: 'http://localhost/images/2.jpeg',
              medium: 'http://localhost/images/2.jpeg',
              big: 'http://localhost/images/2.jpeg'
          },
          {
              small: 'http://localhost/images/3.jpeg',
              medium: 'http://localhost/images/3.jpeg',
              big: 'http://localhost/images/3.jpeg'
          }
      ];
  }
}
