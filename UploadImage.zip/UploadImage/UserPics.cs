﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UploadImage
{
    public class UserPics
    {     
           
            public string PicName { get; set; }            
       
      
    }

    public class GetUserPics
    {
        public string id { get; set; }
        public string src { get; set; }
        public string text { get; set; }
        public string IsProfilePic { get; set; }

    }
}