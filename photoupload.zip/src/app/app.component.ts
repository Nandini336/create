import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {FileUploader} from 'ng2-file-upload';
import { Response, Headers, RequestOptions, 
  ResponseContentType, URLSearchParams } from '@angular/http'; 
  
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  constructor (private http : HttpClient){  
  }
    
  selectedFile : File = null;
  deleteID : string = null;
  str : string = null;
  //public uploader:FileUploader = new FileUploader({url: 'http://localhost:50949/api/Values/UploadJsonFile', itemAlias: 'photo'});
  
  // ngOnInit() {
        
  //   //override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
  //    this.uploader.onAfterAddingFile = (file)=> { file.withCredentials = false; };      
  //   //overide the onCompleteItem property of the uploader so we are 
  //   //able to deal with the server response.
  //     this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
  //           console.log("ImageUpload:uploaded:", item, status, response);
  //      };
  //   }
    
  onClick(event){   
    this.selectedFile  = <File>event.target.files[0];   
   }

upload(event) 
{  
  let form = new FormData();
  form.append('image', this.selectedFile, this.selectedFile.name) 
  this.http.post('http://localhost:50949/api/Values/UploadJsonFile', form)
  .subscribe(res =>{
    console.log('success upload!!!!!!!!');
  })
}

onEnter(event){
this.deleteID = <string>event.target.Values;
}

delete(event){
  let form = new FormData();
  form.append('image', this.str, this.str) 
  this.http.post('http://localhost:50949/api/Values/DeleteFile?image='+this.str,  form)
  .subscribe(res =>{
    console.log('success deleted!!!!!!!!');
  })
 // console.log(this.str);

}

} 
