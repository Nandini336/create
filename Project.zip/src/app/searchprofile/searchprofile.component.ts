import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-searchprofile',
  templateUrl: './searchprofile.component.html'
})
export class SearchprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
     this.loadScript('https://code.jquery.com/jquery-1.11.1.min.js');
     this.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js');
    
    // this.loadScript('#/searchprofile.js');
  }
  public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
}
