import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logo',
  templateUrl: './logo.component.html',
  styleUrls: ['./logo.component.css']
})
export class LogoComponent implements OnInit {
logoImagePath:string;
  constructor() {

    this.logoImagePath = '../../assets/images/Marriage-PNG-HD.png'
   }

  ngOnInit() {
  }

}
