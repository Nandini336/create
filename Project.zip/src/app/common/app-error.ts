
export class AppError { 
    constructor(public originalError?: any) {}
}
