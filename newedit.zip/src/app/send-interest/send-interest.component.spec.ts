import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SendInterestComponent } from './send-interest.component';

describe('SendInterestComponent', () => {
  let component: SendInterestComponent;
  let fixture: ComponentFixture<SendInterestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendInterestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendInterestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
