import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {FileUploader} from 'ng2-file-upload';
import { Response, Headers, RequestOptions, 
  ResponseContentType, URLSearchParams } from '@angular/http'; 
  import { AuthService } from './../services/auth.service';

@Component({
  selector: 'app-image-upload',
  templateUrl: './image-upload.component.html',
  styleUrls: ['./image-upload.component.css']
})
export class ImageUploadComponent implements OnInit {
  title = 'app';
  constructor (private authService: AuthService, private http : HttpClient){  
    
  }
    
  
  selectedFile : File = null;
imageURL :string[] = null;
  deleteID : string = null;
  str : string = null;
  userName : string = this.authService.currentUser.name;
   
  
  //public uploader:FileUploader = new FileUploader({url: 'http://localhost:50949/api/Values/UploadJsonFile', itemAlias: 'photo'});
  
  ngOnInit() {
    this.http.get('http://localhost:50949/api/Values/GetPhotoData/'+this.userName)
    .subscribe(
      (data : any) =>{
        this.imageURL = data;    
      
      }
    )
  //   //override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
  //    this.uploader.onAfterAddingFile = (file)=> { file.withCredentials = false; };      
  //   //overide the onCompleteItem property of the uploader so we are 
  //   //able to deal with the server response.
  //     this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
  //           console.log("ImageUpload:uploaded:", item, status, response);
  //      };
     }
    
  onClick(event){   
    this.selectedFile  = <File>event.target.files[0];   
   }

upload(event) 
{  
  let form = new FormData();
  form.append('image', this.selectedFile, this.selectedFile.name) 
  this.userName = this.authService.currentUser.name; 
  this.http.post('http://localhost:50949/api/Values/UploadPhotoData/'+this.userName, form)
  
  .subscribe(res =>{
    console.log('success upload!!!!!!!!');
  })
}

onEnter(event){
this.deleteID = <string>event.target.Values;
}

imageData : any;
imageName : any;
delete(event){
  this.imageData=event.target.id;
  this.imageName=this.imageData.substring(this.imageData.lastIndexOf('/')+1);
  console.log(this.imageName);
  let form = new FormData();
  form.append('image', this.imageName, this.imageName) 
  this.http.post('http://localhost:50949/api/Values/DeletePhotoData?image='+this.imageName,form)
  .subscribe(res =>{
  console.log('deleted!!!');
 
})

}
}


// delete(event){
//   let form = new FormData();
//   form.append('image', this.str, this.str) 
//   this.http.post('http://localhost:50949/api/Values/DeleteFile?image='+this.str,  form)
//   .subscribe(res =>{
//     console.log('success deleted!!!!!!!!');
//   })
//  // console.log(this.str);

// }
//imageURL : string[] = null;
//getImages(event){

//   let form = new FormData();
//  //form.append('image', this.selectedFile, this.selectedFile.name) 

//   this.http.get('http://localhost:50949/api/Values/GetPhotoData/'+this.userName)
//   .subscribe(
//     (data : any) =>{
//       this.imageURL = data;    
    
//     }
//   )

//   //let form = new FormData();
//   //form.append('image', this.selectedFile, this.selectedFile.name) 
//   // this.http.get('http://localhost:50949/api/Values/GetImage?image='+this.str)
//   // .subscribe(res =>
//   // console.log('Sucess get!!!'))

// }
//}
