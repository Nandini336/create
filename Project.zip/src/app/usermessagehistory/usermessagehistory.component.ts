import { AuthService } from './../services/auth.service';
import { Component, OnInit, Inject } from '@angular/core';
import { HeaderMenuComponent } from '../header/header.component';
import { Router, ActivatedRoute } from "@angular/router";
import { dataService } from "../services/data.service";
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';


class arrayData {
  constructor(public message: string, public message_send_date: string,
              public message_sender: string
  ){}
}
 

@Component({
  selector: 'app-usermessagehistory',
  templateUrl: './usermessagehistory.component.html',
  styleUrls: ['./usermessagehistory.component.css']
})
export class UsermessagehistoryComponent implements OnInit {

  constructor(private authService: AuthService, 
              private router: Router, 
              private dataservice: dataService, 
              private route: ActivatedRoute,
              @Inject(MAT_DIALOG_DATA) public userIdFromHome: any,
              private dialogRef: MatDialogRef<UsermessagehistoryComponent>,

  ) 
  { }

  MessageData : arrayData[]; 
  ngOnInit() {
    let profileId = this.userIdFromHome.responderId;
    
    let messageStatusId = this.userIdFromHome.messageStatusId;
   // console.log("messageStatusId: " + messageStatusId , "responderId " + profileId);
  //  let profileId = this.route.snapshot.params['profileId'];
    //let messageStatusId = this.route.snapshot.params['messageStatusId'];
    let Url;// = "https://webapiangular.azurewebsites.net/api/UserMessages/UserLogMessages?ResponderEmailId="; 
    let param;
    if(messageStatusId==1)
    {
      Url = "https://webapiangular.azurewebsites.net/api/UserMessages/UserLogReqSendMessages?ResponderEmailId=";
      param = Url+ profileId;
    }
    if(messageStatusId==2)
    {
      Url = "https://webapiangular.azurewebsites.net/api/UserMessages/UserLogReqReceivedMessages?ResponderEmailId=";
      param = Url+ profileId;
    }

    if(messageStatusId==4)
    {
      Url = "https://webapiangular.azurewebsites.net/api/UserMessages/UserLogReqRejectedMessages?ResponderEmailId=";
      param = Url+ profileId;
    }

    if(messageStatusId==3)
    {
      Url = "https://webapiangular.azurewebsites.net/api/UserMessages/UserLogReqPendingMessages?ResponderEmailId=";
      param = Url+ profileId;
    }

    if(messageStatusId==null)
    {
      Url = "https://webapiangular.azurewebsites.net/api/UserMessages/UserLogMessages?ResponderEmailId=";
      param = Url+profileId;
    }
//console.log(param);
    this.dataservice.getData(param).subscribe((res: any) => 
    { this.MessageData = res });
  }

  gotoBack()
  {
    this.router.navigate(['/']);
    
  }
  close() {
    this.dialogRef.close();
}
}
