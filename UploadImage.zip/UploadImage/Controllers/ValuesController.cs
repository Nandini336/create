﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using System.Web.Http.Cors;
using System.Web;
using System.IO;

namespace UploadImage.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]

    public class ValuesController : ApiController
    {

        // GET api/values
       
       // [HttpPost, ActionName("Data")]

        //[HttpPost]
        //[Route("~/api/Values/FileUploadData")]
        //public string FileUploadData(UserPics userPics)
        //{
        //    var data = userPics;
        //    string con = ConfigurationManager.ConnectionStrings["SqlServerConnString"].ConnectionString;
        //    CRUD repository = new CRUD();
        //    return repository.InsertUserProfilePics(con, data);
        //    //InsertUserProfilePics
        //}


        [HttpPost]
        [Route("~/api/Values/PhotoUploadData")]
        public HttpResponseMessage PhotoUploadData()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            string imagName = null;
            var httpRequest = HttpContext.Current.Request;

            if (httpRequest.Files.Count > 0)
            {
                foreach (string file in httpRequest.Files)
                {
                    var postedFile = httpRequest.Files["Image"];
                    imagName = new string(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray());
                    CRUD crudObj = new CRUD();
                    crudObj.PostData("uspInsertImages2", imagName);
                    return Request.CreateResponse(HttpStatusCode.OK, imagName);                   
                }
            }
            return response;

        }

        [HttpPost]
        [Route("~/api/Values/DeleteFile")]
        public HttpResponseMessage DeleteFile(string image)
        {
            CRUD crudObj = new CRUD();
            crudObj.DeleteData("uspDeleteImage", image);
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        [HttpPost]
        [Route("~/api/Values/UploadJsonFile")]
        public HttpResponseMessage UploadJsonFile()
        {

            HttpResponseMessage response = new HttpResponseMessage();
            string imagName = null;
            var httpRequest = HttpContext.Current.Request;

            if (httpRequest.Files.Count > 0)
            {
                foreach (string file in httpRequest.Files)
                {
                   var postedFile = httpRequest.Files["Image"];
                   imagName = new string(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray());                   
                   var filePath = HttpContext.Current.Server.MapPath("~/Images/" + postedFile.FileName);                    
                   postedFile.SaveAs(filePath);
                }
            }
            return response;

            
        }
    }
}
