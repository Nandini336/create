import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'loading-component',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.css']
})
export class LoadingComponent implements OnInit {
  loadingImagePath: string;
  constructor() {
    this.loadingImagePath = '../../assets/images/lg.rotating-balls-spinner.gif'
   }

  ngOnInit() {
  }

}
