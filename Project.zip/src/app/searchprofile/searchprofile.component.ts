import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http' ;
// import { HttpClient } from '../../../node_modules/@types/selenium-webdriver/http';
import {Http,Response} from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import {Observable} from 'rxjs/Rx';
import 'rxjs';
import {MatDialog, MatDialogConfig} from "@angular/material";
import { SendInterestComponent } from '../send-interest/send-interest.component';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-searchprofile',
  templateUrl: './searchprofile.component.html'
})
export class SearchprofileComponent implements OnInit {

  constructor(private http:HttpClient,  private dialog: MatDialog, private authService: AuthService) { }
  myData:any;
  ngOnInit() {
    
     this.loadScript('https://code.jquery.com/jquery-1.11.1.min.js');
     this.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js');
     this.http.get('https://webapiangular.azurewebsites.net/api/Registration/GetAllProfiles?emailid='+ this.authService.currentUser.name)
     .subscribe(
      data => {
        this.myData = data;
      }
    );

    
 
  }
  public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
  
  SendInterest(userEmaiId)
  {
  const dialogConfig = new MatDialogConfig();

  dialogConfig.disableClose = true;
  dialogConfig.autoFocus = true;
  dialogConfig.data = {
    width: '450px',
    //data: { emaiId: userEmaiId}
};

  this.dialog.open(SendInterestComponent, dialogConfig);
  }
}
