﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using System.Web.Http.Cors;
using System.Web;
using System.IO;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Text;

namespace UploadImage.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]   
    public class ValuesController : ApiController
    {
        string connString = ConfigurationManager.ConnectionStrings["AzureConnString"].ConnectionString;
       
        testClass testClass = new testClass();
        testClass test = new testClass();
       

        StringBuilder s = new StringBuilder();

        int i = 3;

        [HttpGet]
        [Route("~/api/Values/GetPhotoData/{uid}")]
        public List<string> GetPhotoData(string uid)
        {           
            
            List<string> blobImageContent = GetPhotoURI(uid);
            return blobImageContent;
        }

        public List<string> GetPhotoURI(string userName)
        {
           // var userName = "amit@gmail.com";           
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connString);           
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();            
            CloudBlobContainer container = blobClient.GetContainerReference("azurecontainer443");
            var list = container.ListBlobs().OfType<CloudBlockBlob>().ToList();
            List<CloudBlockBlob> blobNames = new List<CloudBlockBlob>();
            foreach (var item in list)
            {
                if (item.Uri.ToString().Contains(userName))
                {
                    blobNames.Add(item);
                }

            }
            var listOfBlobURI = new List<string>();
            foreach (var blob in blobNames)
            {
                var blobFileName = blob.Uri.Segments.Last();
                CloudBlockBlob blobReference = container.GetBlockBlobReference(blobFileName);
                string datauri = blobReference.Uri.ToString();
                listOfBlobURI.Add(datauri);
            }
            return listOfBlobURI;
        }

        [HttpPost]
        [Route("~/api/Values/UploadPhotoData/{uid}")]
        public HttpResponseMessage PhotoUploadData(string uid)
        {
            string userName = uid;
            HttpResponseMessage response = new HttpResponseMessage();
            string imagName = null;
            var httpRequest = HttpContext.Current.Request;

            if (httpRequest.Files.Count > 0)
            {
                foreach (string file in httpRequest.Files)
                {
                    var postedFile = httpRequest.Files["Image"];
                    imagName = userName + postedFile.FileName;
                   // imagName = userName + new string(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray());
                    var filePath = HttpContext.Current.Server.MapPath("~/Images/" + imagName);
                    postedFile.SaveAs(filePath);                    
                }
            }
          
            string localFolder = ConfigurationManager.AppSettings["sourceFolder"];
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(connString);
            CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference("azurecontainer443");
            cloudBlobContainer.CreateIfNotExists();           

            string[] fileEntries = Directory.GetFiles(localFolder);
            foreach (var item in fileEntries)
            {
                string key = Path.GetFileName(item);
                CloudBlockBlob blob = cloudBlobContainer.GetBlockBlobReference(key);
                using (var fs = System.IO.File.Open(item, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    blob.UploadFromStream(fs);

                }
            }

            return response;

        }

        [HttpPost]
        [Route("~/api/Values/DeletePhotoData")]
        public string DeleteFile(string image)
        {
            string message= DeletePhotoURI(image);
            return message;
        }

        public string DeletePhotoURI(string imageName)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connString);
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("azurecontainer443");
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(imageName);
            var result = blockBlob.DeleteIfExists();
            string message = "Successfully deleted";
            return message;
        }

        //[HttpPost]
        //[Route("~/api/Values/UploadJsonFile")]
        //public HttpResponseMessage UploadJsonFile()
        //{

        //    HttpResponseMessage response = new HttpResponseMessage();
        //    string imagName = null;
        //    var httpRequest = HttpContext.Current.Request;

        //    if (httpRequest.Files.Count > 0)
        //    {
        //        foreach (string file in httpRequest.Files)
        //        {
        //           var postedFile = httpRequest.Files["Image"];
        //           imagName = new string(Path.GetFileNameWithoutExtension(postedFile.FileName).Take(10).ToArray());                   
        //           var filePath = HttpContext.Current.Server.MapPath("~/Images/" + postedFile.FileName);                    
        //           postedFile.SaveAs(filePath);
        //        }
        //    }
        //    return response;

            
        //}


      
    }


   
    
}
//[LuisIntent(ConstIntents.UnknownIntent)]
//public async Task Unknown_Intent(IDialogContext context, IAwaitable<IMessageActivity> activity, LuisResult result)
//{
//    var messageActivity = await activity;
//    // CosmosDbData.UserReplyWithIntent(context, messageActivity.Text.ToString(), ConstIntents.UnknownIntent);

//    // var message = $"Can you please elaborate your query about **{result.Query}**";
//    string message = "I can help you with the below categoires: \n\n 1. Fuel\n\n 2. Oil\n\n 3. Ropes\n\n 4. Refrigerants\n\n " +
//        "5. Galley and Accomodation\n\n 6. C and M\n\n 7. Welding\n\n  8. Air";
//    // await context.PostAsync(message);           
//    PromptDialog.Text(context, this.MainProductSelection, message);
//    //CosmosDbData.BotResponse(message, context, ConstIntents.UnknownIntent, ListCreateDbData);
//    // context.Wait(this.MessageReceived);
//}

//private async Task MainProductSelection(IDialogContext context, IAwaitable<string> result)
//{
//    var message = await result;
//    //  CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

//    string prompt;
//    switch (message.ToString())
//    {
//        case "Fuel":
//        case "1":
//            prompt = $"Please select from  the below options:\n\n 1.Heavy oil\n\n 2.Diesel Oil";
//            PromptDialog.Text(context, this.SubProductSelection, prompt);

//            break;
//        case "Oil":
//        case "2":
//            prompt = $"We are still working on it... please bare with us";
//            break;
//        case "Ropes":
//        case "3":
//            prompt = "We are still working on it... please bare with us";
//            break;
//        case "Refrigerants":
//        case "4":
//            prompt = "We are still working on it... please bare with us";
//            break;
//        case "Galley and Accomodation":
//        case "5":
//            prompt = "We are still working on it... please bare with us";
//            break;
//        case "C and M":
//        case "6":
//            prompt = "We are still working on it... please bare with us";
//            break;
//        case "Welding":
//        case "7":
//            prompt = "We are still working on it... please bare with us";
//            break;
//        case "Air":
//        case "8":
//            prompt = "We are still working on it... please bare with us";
//            break;
//        default:
//            prompt = "You have selected an invalid option. Please select valid option (**example 1, 2, 3 .....**)";
//            MailContent.ChatDataForUserandBot(context, prompt);
//            CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
//            PromptDialog.Text(context, this.MainProductSelection, prompt);
//            return;
//    }
//}

//private async Task SubProductSelection(IDialogContext context, IAwaitable<string> result)
//{
//    var message = await result;
//    CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

//    string prompt;
//    switch (message.ToString())
//    {
//        case "Heavy oil":
//        case "1":
//            prompt = $"Please select from  the below options:\n\n 1. Sludge in heavy oil\n\n 2. Soot in boilers\n\n 3. Corrosion in heavy oil\n\n 4. Improper combustion in heavy oil";
//            await context.PostAsync(prompt);
//            context.Wait(this.IntentSelection);

//            break;
//        case "Diesel Oil":
//        case "2":
//            prompt = $"We are still working on it... please bare with us";

//            break;

//        default:
//            prompt = "You have selected an invalid option. Please select valid option (**example 1, 2, 3 .....**)";
//            MailContent.ChatDataForUserandBot(context, prompt);
//            CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
//            PromptDialog.Text(context, this.SubProductSelection, prompt);
//            return;
//    }
//}

//private async Task IntentSelection(IDialogContext context, IAwaitable<IMessageActivity> activity)
//{
//    var messageActivity = await activity;
//    var message = messageActivity.Text;

//    CosmosDbData.UserReplyWithoutIntent(context, message.ToString());

//    string prompt;
//    switch (message.ToString())
//    {
//        case "1":
//            var HeavySludge = new HeavySludge(this.ListCreateDbData);
//            await HeavySludge.MainAsync(context, activity, ListCreateDbData);
//            break;

//        case "2":
//            var HeavySoot = new HeavySoot(this.ListCreateDbData);
//            await HeavySoot.MainAsync(context, activity, ListCreateDbData);
//            break;

//        case "3":
//            var heavy_Corrosion = new Heavy_Corrosion(this.ListCreateDbData);
//            await heavy_Corrosion.MainAsync(context, activity, ListCreateDbData);
//            break;

//        case "4":
//            var Heavy_ImproperCombustion = new Heavy_ImproperCombustion(this.ListCreateDbData);
//            await Heavy_ImproperCombustion.MainAsync(context, activity, ListCreateDbData);
//            break;
//        default:
//            prompt = "You have selected an invalid option. Please select valid option (**example 1, 2, 3 .....**)";
//            MailContent.ChatDataForUserandBot(context, prompt);
//            CosmosDbData.BotResponse(prompt, context, "", ListCreateDbData);
//            await context.PostAsync(prompt);
//            //context.Wait(this.IntentSelection);
//            //PromptDialog.Text(context, this.IntentSelection, prompt);

//            return;
//    }
//}