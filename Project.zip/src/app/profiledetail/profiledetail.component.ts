import { Component, OnInit } from '@angular/core';
//import 'myProfile.js'

@Component({
  selector: 'app-profiledetail',
  templateUrl: './profiledetail.component.html',
  styleUrls: ['./profiledetail.component.css']
})
export class ProfiledetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
