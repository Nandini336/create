import { Component, OnInit, Inject } from '@angular/core';
import { Router } from "@angular/router";
import {
    ReactiveFormsModule,
    FormsModule,
    FormGroup,
    FormControl,
    Validators,
    FormBuilder
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '../../../node_modules/@angular/material';


export interface FormModel {
  captcha?: string;
}

@Component({
  selector: 'app-forgetprofile',
  templateUrl: './forgetprofile.component.html'
})
export class ForgetprofileComponent implements OnInit {
public formModel: FormModel = {};
  constructor(private router: Router,  @Inject(MAT_DIALOG_DATA) public userIdFromHome: any,
  private dialogRef: MatDialogRef<ForgetprofileComponent>,) { }

  ngOnInit() {
  }
gotoLogin()
    {
      this.dialogRef.close();
    }
    close() {
      this.dialogRef.close();
  }
}
