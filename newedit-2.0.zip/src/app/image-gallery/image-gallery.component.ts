import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//import { NgxImageGalleryComponent, GALLERY_IMAGE, GALLERY_CONF } from "ngx-image-gallery";
import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import { Response, Headers, RequestOptions, 
    ResponseContentType, URLSearchParams } from '@angular/http'; 
    
  // import * as $ from 'jquery';

  declare var $:any;

@Component({
  selector: 'app-root',
  templateUrl: './image-gallery.component.html',
  styleUrls: ['./image-gallery.component.css']
}) 

export class ImageGalleryComponent implements OnInit { 
    
    constructor (private http : HttpClient){  
    }
      
    selectedFile : File = null;
  deleteID : string = null;
  str : string = null;
  imageURL : string[] = null;
  imageCount : any;
  
  //public uploader:FileUploader = new FileUploader({url: 'http://localhost:50949/api/Values/UploadJsonFile', itemAlias: 'photo'});
  
  // ngOnInit() {
        
  //   //override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
  //    this.uploader.onAfterAddingFile = (file)=> { file.withCredentials = false; };      
  //   //overide the onCompleteItem property of the uploader so we are 
  //   //able to deal with the server response.
  //     this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
  //           console.log("ImageUpload:uploaded:", item, status, response);
  //      };
  //   }
    
  onClick(event){   
    this.selectedFile  = <File>event.target.files[0];   
   }

upload(event) 
{  
  let form = new FormData();
  form.append('image', this.selectedFile, this.selectedFile.name) 
   
  this.http.post('http://localhost:50949/api/Values/UploadPhotoData', form)
  
  .subscribe(res =>{
    console.log('success upload!!!!!!!!');
  })
}

onEnter(event){
this.deleteID = <string>event.target.Values;
}

delete(event){
  let form = new FormData();
  form.append('image', this.str, this.str) 
  this.http.post('http://localhost:50949/api/Values/DeletePhotoData?image='+this.str,  form)
  .subscribe(res =>{
    console.log('success deleted!!!!!!!!');
  })
 // console.log(this.str);

}

getImages(event){
  //let form = new FormData();
  //form.append('image', this.selectedFile, this.selectedFile.name) 
  this.http.get('http://localhost:50949/api/Values/GetPhotoData')
  .subscribe(
    (data : any) =>{
      this.imageURL = data;
      this.imageCount - this.imageURL.length;
      console.log(this.imageCount);
    }
  )
}

    //Java Script code for image gallery
     ngOnInit(): void {
// $('.getImages').click(function(){
 
//     $(".item").addClass("active");


//});
  }

  

}