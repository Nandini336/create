﻿using System;
using Dapper;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
using System.IO;
using WebApi.Jwt;

namespace UploadImage
{
    public class CRUD
    {
        IDbConnection db = new SqlConnection(ConfigurationManager.ConnectionStrings["LocalDbConnString"].ConnectionString);
        string ConnectionString = ConfigurationManager.ConnectionStrings["LocalDbConnString"].ConnectionString;

        public GetLoginInfo GetUserLoginInfo(string conn, string uid, string pwd)
        {
            using (IDbConnection db = new SqlConnection(conn))
            {
                string readSp = "GetLoginInfo";
                var para = new DynamicParameters();
                para.Add("@username", uid);
                para.Add("@password", pwd);
                var data = db.Query<GetLoginInfo>(readSp, para, commandType: CommandType.StoredProcedure).FirstOrDefault();
                return data;
            }
        }

        public void PostData(string storedProc, params object[] param)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@name",param[0]);
            parameters.Add("@contenttype", param[1]);
            parameters.Add("@data", param[2]);          

            db.Query(storedProc, parameters, commandType: CommandType.StoredProcedure);


        }

        public void DeleteData(string storedProc, params object[] param)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@name", param[0]);
            db.Query(storedProc, parameters, commandType: CommandType.StoredProcedure);
        }

        public string InsertUserProfilePics(string conn, UserPics userPics)
        {

            string msg = string.Empty;
           
            var para = new DynamicParameters();
            var outPut = new DynamicParameters();
            try
            {
                para.Add("@name", userPics.PicName);               
               var result = ExecuteSpReturnMessage("uspInsertImages2", para, null, true, null);
                msg = "Image inserted successfully";

            }
            catch (Exception exp)
            {
                msg = "Error :" + exp.Message;
            }
           
            //int valueout = para.Get<int>("@outresult");
            return msg ;
        }

        public IEnumerable ExecuteSpReturnMessage(string storedProcedure, dynamic param = null,
         SqlTransaction transaction = null,

         bool buffered = true, int? commandTimeout = null)
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();
            var returnMessage = connection.Query(storedProcedure, param: (object)param, transaction: transaction, buffered: buffered, commandTimeout: commandTimeout, commandType: CommandType.StoredProcedure);
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
            return returnMessage;
        }


    }
}