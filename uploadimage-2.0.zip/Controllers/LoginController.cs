﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApi.Jwt;

namespace UploadImage.Controllers
{
    [AllowAnonymous]
    public class LoginController : ApiController
    {
        [HttpGet]
        [Route("~/api/Login/Get/{username}/{password}")]
        public HttpResponseMessage Get(string username, string password)
        {
            if (CheckUser(username, password))
            {
                var token = JwtManager.GenerateToken(username);
                var response = Request.CreateResponse(HttpStatusCode.OK, token);
                return response;
            }
            else
            {
                var token = JwtManager.GenerateTokenFake(username);
                var response = Request.CreateResponse(HttpStatusCode.OK, token);
                return response;

            }
            throw new HttpResponseException(HttpStatusCode.Unauthorized);
        }
        public bool CheckUser(string username, string password)
        {
            bool flag = true;
            GetLoginInfo getdata = getUserLoginInfoData(username, password);
           // if (getdata.Code == null)
           // {
           //     return flag = false;
            //}
            return flag;
        }
        private GetLoginInfo getUserLoginInfoData(string username, string password)
        {
            string con = ConfigurationManager.ConnectionStrings["LocalDbConnString"].ConnectionString;
            CRUD repository = new CRUD();
            var data = repository.GetUserLoginInfo(con, username, password);
            return data;
        }

        /*
     [HttpPost]
     public HttpResponseMessage Post(loginobject credentials)
     {

         if (CheckUser(credentials.email, credentials.password))
         {
             var token = JwtManager.GenerateToken(credentials.email);
             var response = Request.CreateResponse(HttpStatusCode.OK, token);
             return response;
         }

         throw new HttpResponseException(HttpStatusCode.Accepted);
     }
     */
    }
}